var class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot_global_actions =
[
    [ "instance", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot_global_actions.html#ad69b777c4d167fc49f917e9173b245cc", null ]
];