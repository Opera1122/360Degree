var class_infinity_code_1_1u_pano_1_1_actions_1_1_open_u_r_l =
[
    [ "Invoke", "class_infinity_code_1_1u_pano_1_1_actions_1_1_open_u_r_l.html#a3f68fad47f7335d46779c585ba608fbe", null ],
    [ "url", "class_infinity_code_1_1u_pano_1_1_actions_1_1_open_u_r_l.html#a8054ee9078e9fd7dcb43cba72e41ad7a", null ]
];