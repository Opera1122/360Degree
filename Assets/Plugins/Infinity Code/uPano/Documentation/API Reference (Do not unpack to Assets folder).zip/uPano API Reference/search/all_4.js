var searchData=
[
  ['fromcolor32_42',['FromColor32',['../class_infinity_code_1_1_tiny_terrain_1_1_color16.html#a8b703710a08db1ab0eb9d124a9a3e7a5',1,'InfinityCode::TinyTerrain::Color16']]]
];
