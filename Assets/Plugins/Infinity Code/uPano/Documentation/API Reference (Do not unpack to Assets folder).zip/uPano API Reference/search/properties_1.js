var searchData=
[
  ['basemapresolution_263',['baseMapResolution',['../class_infinity_code_1_1_tiny_terrain_1_1_tiny_terrain_data.html#ac3b6fb4ffdc04161b028b0f2a0622bf2',1,'InfinityCode::TinyTerrain::TinyTerrainData']]]
];
