var searchData=
[
  ['defaultsettings_265',['defaultSettings',['../class_infinity_code_1_1_tiny_terrain_1_1_compression_settings.html#a30825c928701020fe585e50bae267d2e',1,'InfinityCode::TinyTerrain::CompressionSettings']]],
  ['detailmap_266',['detailmap',['../class_infinity_code_1_1_tiny_terrain_1_1_tiny_terrain_data.html#a47d094495fa146afc9c8b671a68ab24f',1,'InfinityCode::TinyTerrain::TinyTerrainData']]],
  ['detailmapspacesaving_267',['detailmapSpaceSaving',['../class_infinity_code_1_1_tiny_terrain_1_1_compression_info.html#aa71b85c86a5e9454007c37818a6a794b',1,'InfinityCode::TinyTerrain::CompressionInfo']]],
  ['detailprototypes_268',['detailPrototypes',['../class_infinity_code_1_1_tiny_terrain_1_1_tiny_terrain_data.html#a25f6b8b19053db67152cb9de1d2894ae',1,'InfinityCode::TinyTerrain::TinyTerrainData']]],
  ['detailresolutionperpatch_269',['detailResolutionPerPatch',['../class_infinity_code_1_1_tiny_terrain_1_1_tiny_terrain_data.html#aaba35f416563f0339fc4626f15e8b13a',1,'InfinityCode::TinyTerrain::TinyTerrainData']]]
];
