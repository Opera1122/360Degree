var searchData=
[
  ['useinstancing_130',['useInstancing',['../class_infinity_code_1_1_tiny_terrain_1_1_tiny_detail_prototype.html#af9d35d6f6ffba73fd27981768267b74c',1,'InfinityCode::TinyTerrain::TinyDetailPrototype']]],
  ['useprototypemesh_131',['usePrototypeMesh',['../class_infinity_code_1_1_tiny_terrain_1_1_tiny_detail_prototype.html#a11bb51943230986e2d4b8771bf21d92e',1,'InfinityCode::TinyTerrain::TinyDetailPrototype']]]
];
