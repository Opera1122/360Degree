var searchData=
[
  ['getoriginalsize_171',['GetOriginalSize',['../class_infinity_code_1_1_tiny_terrain_1_1_compressors_1_1_alphamap_compressor.html#a8cd010d081a9232326e4455609c4cf61',1,'InfinityCode.TinyTerrain.Compressors.AlphamapCompressor.GetOriginalSize()'],['../class_infinity_code_1_1_tiny_terrain_1_1_compressors_1_1_detailmap_compressor.html#afcf790ad145f5a3fa1ceead4487dc69f',1,'InfinityCode.TinyTerrain.Compressors.DetailmapCompressor.GetOriginalSize()']]]
];
