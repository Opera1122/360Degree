var searchData=
[
  ['compressionratio_264',['compressionRatio',['../class_infinity_code_1_1_tiny_terrain_1_1_compression_info.html#a44b33c8439809d199507ccb33b932905',1,'InfinityCode::TinyTerrain::CompressionInfo']]]
];
