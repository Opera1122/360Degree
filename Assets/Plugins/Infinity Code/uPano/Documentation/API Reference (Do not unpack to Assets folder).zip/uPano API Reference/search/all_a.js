var searchData=
[
  ['noiseseed_76',['noiseSeed',['../class_infinity_code_1_1_tiny_terrain_1_1_tiny_detail_prototype.html#a8a50bc71d0b3ec7cd51eab09c8f66e77',1,'InfinityCode::TinyTerrain::TinyDetailPrototype']]],
  ['noisespread_77',['noiseSpread',['../class_infinity_code_1_1_tiny_terrain_1_1_tiny_detail_prototype.html#a72c5604cf085f7fa4b1c63266d35c99d',1,'InfinityCode::TinyTerrain::TinyDetailPrototype']]]
];
