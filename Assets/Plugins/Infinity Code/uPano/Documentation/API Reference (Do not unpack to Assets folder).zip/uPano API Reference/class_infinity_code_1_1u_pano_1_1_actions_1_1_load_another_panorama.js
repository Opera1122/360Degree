var class_infinity_code_1_1u_pano_1_1_actions_1_1_load_another_panorama =
[
    [ "Invoke", "class_infinity_code_1_1u_pano_1_1_actions_1_1_load_another_panorama.html#a3431cbfec903b5a7a897c845a4a4e17f", null ],
    [ "keepOrientation", "class_infinity_code_1_1u_pano_1_1_actions_1_1_load_another_panorama.html#a9826847eecf9e9eb859fb8f7649b40e3", null ],
    [ "prefab", "class_infinity_code_1_1u_pano_1_1_actions_1_1_load_another_panorama.html#a88d6ae2bd1a212eab5a11d525eed6418", null ]
];