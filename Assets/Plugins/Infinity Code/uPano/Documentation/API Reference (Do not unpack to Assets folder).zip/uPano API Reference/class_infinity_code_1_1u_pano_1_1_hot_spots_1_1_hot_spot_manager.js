var class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot_manager =
[
    [ "Create", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot_manager.html#a51e4ada8981cc22903f88cfef4bab811", null ],
    [ "container", "class_infinity_code_1_1u_pano_1_1_hot_spots_1_1_hot_spot_manager.html#aa6b6e805c7de044b0de927aa63fda3ed", null ]
];