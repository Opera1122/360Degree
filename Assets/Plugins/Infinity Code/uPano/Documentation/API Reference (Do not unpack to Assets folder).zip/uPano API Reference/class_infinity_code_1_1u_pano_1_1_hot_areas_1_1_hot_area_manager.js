var class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area_manager =
[
    [ "Create", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area_manager.html#a0bc879fc3a9d962e2e1b8e6782ce356c", null ],
    [ "GetActiveArea", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area_manager.html#a17ce6b1ef161834d666ed4a9dac66fbc", null ],
    [ "GetArea", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area_manager.html#a81df7e9162e75f858eedc558a66014e3", null ]
];