var class_infinity_code_1_1u_pano_1_1_plugins_1_1_auto_rotate =
[
    [ "accelerationCurve", "class_infinity_code_1_1u_pano_1_1_plugins_1_1_auto_rotate.html#a4c7238539f72914237f24ba51468d770", null ],
    [ "panSpeed", "class_infinity_code_1_1u_pano_1_1_plugins_1_1_auto_rotate.html#a9554d5988a4e432964ffc303fba675de", null ],
    [ "restoreAfter", "class_infinity_code_1_1u_pano_1_1_plugins_1_1_auto_rotate.html#a951fcd124f883d1a75cb55943c8aad35", null ],
    [ "restoreByTimer", "class_infinity_code_1_1u_pano_1_1_plugins_1_1_auto_rotate.html#ab3b955a6633b91d0054bcceebac1488c", null ],
    [ "startDelay", "class_infinity_code_1_1u_pano_1_1_plugins_1_1_auto_rotate.html#a13ddf6915e1829cb33c36c62c4567766", null ],
    [ "stopOnInput", "class_infinity_code_1_1u_pano_1_1_plugins_1_1_auto_rotate.html#a1466c0bd97402a0535013370ee7e08dd", null ],
    [ "tiltSpeed", "class_infinity_code_1_1u_pano_1_1_plugins_1_1_auto_rotate.html#a7fd8a0eb2eac82e390bd8a359bb63c63", null ],
    [ "paused", "class_infinity_code_1_1u_pano_1_1_plugins_1_1_auto_rotate.html#a3bef26b63f4973fd3e12853f56791060", null ]
];