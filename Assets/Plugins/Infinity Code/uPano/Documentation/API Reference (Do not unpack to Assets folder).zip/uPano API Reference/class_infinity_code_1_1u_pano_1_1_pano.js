var class_infinity_code_1_1u_pano_1_1_pano =
[
    [ "CameraType", "class_infinity_code_1_1u_pano_1_1_pano.html#ac498b3c2b421ed56949527ec09094aaa", [
      [ "createNew", "class_infinity_code_1_1u_pano_1_1_pano.html#ac498b3c2b421ed56949527ec09094aaaae637d54b8acec09184b36cbc306ad701", null ],
      [ "existing", "class_infinity_code_1_1u_pano_1_1_pano.html#ac498b3c2b421ed56949527ec09094aaaaf4e0ac58eb46d88efc451c164db3b837", null ]
    ] ],
    [ "NewCameraDepthType", "class_infinity_code_1_1u_pano_1_1_pano.html#a9dd37c92463a8078dd33150a56052386", [
      [ "autoDetect", "class_infinity_code_1_1u_pano_1_1_pano.html#a9dd37c92463a8078dd33150a56052386a7b81251f96bcb4e8fecc04a09f3bb8e2", null ],
      [ "manual", "class_infinity_code_1_1u_pano_1_1_pano.html#a9dd37c92463a8078dd33150a56052386a3c78b35502b2693fefdfc51cba3a53a5", null ]
    ] ],
    [ "Projection", "class_infinity_code_1_1u_pano_1_1_pano.html#adde9a3e3a054ceb4db09e71d1987bf29", [
      [ "perspective", "class_infinity_code_1_1u_pano_1_1_pano.html#adde9a3e3a054ceb4db09e71d1987bf29ac77848cc02fefd0c360ce733a4affd93", null ],
      [ "orthographic", "class_infinity_code_1_1u_pano_1_1_pano.html#adde9a3e3a054ceb4db09e71d1987bf29a4e5071bdaf4b6fda36b4a084480682eb", null ]
    ] ],
    [ "RotationMode", "class_infinity_code_1_1u_pano_1_1_pano.html#a9a8f52c821629b3f317324ed90dc8816", [
      [ "rotateCamera", "class_infinity_code_1_1u_pano_1_1_pano.html#a9a8f52c821629b3f317324ed90dc8816a8a721987a95c65a76270df13b83574a9", null ],
      [ "rotatePanorama", "class_infinity_code_1_1u_pano_1_1_pano.html#a9a8f52c821629b3f317324ed90dc8816a90326670f6f0b21f17d8f77374f4019a", null ],
      [ "rotateGameObject", "class_infinity_code_1_1u_pano_1_1_pano.html#a9a8f52c821629b3f317324ed90dc8816a312f4bdca2de5b0bcd058b592212efb2", null ]
    ] ],
    [ "LookAt", "class_infinity_code_1_1u_pano_1_1_pano.html#a90ffa44c40335f29c8e786a9169eae37", null ],
    [ "UpdateRotation", "class_infinity_code_1_1u_pano_1_1_pano.html#a74f08bfb3d3939134f6e1ecb980c6601", null ],
    [ "VerifyFOV", "class_infinity_code_1_1u_pano_1_1_pano.html#a61db5cef1db389a20f388eb13c785b9a", null ],
    [ "VerifyPan", "class_infinity_code_1_1u_pano_1_1_pano.html#a42156cec7f653c09f682389fbfcd263c", null ],
    [ "VerifyTilt", "class_infinity_code_1_1u_pano_1_1_pano.html#a4484cdafa2aa35029abb129d80b73fff", null ],
    [ "isPreview", "class_infinity_code_1_1u_pano_1_1_pano.html#a416b6d8c017972c75204ad770249da25", null ],
    [ "locked", "class_infinity_code_1_1u_pano_1_1_pano.html#a61ba718d5820ae910d54e7cb546ee56c", null ],
    [ "OnFOVChanged", "class_infinity_code_1_1u_pano_1_1_pano.html#a261643926c918e485e545c1237129eed", null ],
    [ "OnGetInputPosition", "class_infinity_code_1_1u_pano_1_1_pano.html#aacd28cced5268d7adf7e40c13bcf4f66", null ],
    [ "OnPanChanged", "class_infinity_code_1_1u_pano_1_1_pano.html#ade0f00244bbb0c0b7492bdc964c5da41", null ],
    [ "OnPanoDestroy", "class_infinity_code_1_1u_pano_1_1_pano.html#ab62c51c34aa0892a1b8fb1fd6ed4b7ea", null ],
    [ "OnPanoEnabled", "class_infinity_code_1_1u_pano_1_1_pano.html#afb6e7c4d0ecadbe066fc455baacc7a14", null ],
    [ "OnPanoStarted", "class_infinity_code_1_1u_pano_1_1_pano.html#ae0f1d65472ce8f207e3d5bd500f6b484", null ],
    [ "OnPanoUnloaded", "class_infinity_code_1_1u_pano_1_1_pano.html#a0eb3cccecdbf21d6f8d58fb93bd17184", null ],
    [ "OnTiltChanged", "class_infinity_code_1_1u_pano_1_1_pano.html#a5b371749de382ff412e3c3f017e78ae2", null ],
    [ "OnVerifyFOV", "class_infinity_code_1_1u_pano_1_1_pano.html#af8db572fffc208c88f686bd12bae9024", null ],
    [ "OnVerifyPan", "class_infinity_code_1_1u_pano_1_1_pano.html#a6d4d5d165e1f215e7a5433945e4323dd", null ],
    [ "OnVerifyTilt", "class_infinity_code_1_1u_pano_1_1_pano.html#a201d26ecfd2868de348e7da6e132673d", null ],
    [ "version", "class_infinity_code_1_1u_pano_1_1_pano.html#ab2da71dca661eb27e50b79f563936a16", null ],
    [ "activeCamera", "class_infinity_code_1_1u_pano_1_1_pano.html#a01693107ffdf882bfaa0b2ed7d61c43a", null ],
    [ "fov", "class_infinity_code_1_1u_pano_1_1_pano.html#af251b126876ec1786d02231c3ceb8746", null ],
    [ "localPan", "class_infinity_code_1_1u_pano_1_1_pano.html#aa4c362399699b686ebe1985dce3dd69a", null ],
    [ "northPan", "class_infinity_code_1_1u_pano_1_1_pano.html#aa90f2c3d94203cf646d87ceb4314055a", null ],
    [ "pan", "class_infinity_code_1_1u_pano_1_1_pano.html#ad57d2f04a53f7e73e578ce56f74fd77f", null ],
    [ "panoRenderer", "class_infinity_code_1_1u_pano_1_1_pano.html#aefc25ad4a6e14cd84b7527ca982521f6", null ],
    [ "rotateGameObject", "class_infinity_code_1_1u_pano_1_1_pano.html#a3e8197260347cfa047a76be1a7fea45d", null ],
    [ "rotationMode", "class_infinity_code_1_1u_pano_1_1_pano.html#ad20a5dce410bd4f1af0de9f79a1f5b5e", null ],
    [ "tilt", "class_infinity_code_1_1u_pano_1_1_pano.html#a4e482685c900cae312adda74bee69718", null ]
];