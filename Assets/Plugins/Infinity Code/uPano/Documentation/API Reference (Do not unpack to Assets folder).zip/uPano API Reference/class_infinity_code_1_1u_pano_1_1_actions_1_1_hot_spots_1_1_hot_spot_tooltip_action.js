var class_infinity_code_1_1u_pano_1_1_actions_1_1_hot_spots_1_1_hot_spot_tooltip_action =
[
    [ "Hide", "class_infinity_code_1_1u_pano_1_1_actions_1_1_hot_spots_1_1_hot_spot_tooltip_action.html#a57b60b90e1d52f39c043864a98c3ab67", null ],
    [ "Show", "class_infinity_code_1_1u_pano_1_1_actions_1_1_hot_spots_1_1_hot_spot_tooltip_action.html#a6ccd476174aa9ddd0f7439c7cff6e37a", null ],
    [ "text", "class_infinity_code_1_1u_pano_1_1_actions_1_1_hot_spots_1_1_hot_spot_tooltip_action.html#a86e7504023f4d195355e2eaa42a077ba", null ],
    [ "tooltipPrefab", "class_infinity_code_1_1u_pano_1_1_actions_1_1_hot_spots_1_1_hot_spot_tooltip_action.html#a11608b0701e7cc9a34ebe2f06f53ee5c", null ]
];