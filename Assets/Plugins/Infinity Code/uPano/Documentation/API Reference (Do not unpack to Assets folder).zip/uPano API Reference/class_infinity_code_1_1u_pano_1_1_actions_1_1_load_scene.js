var class_infinity_code_1_1u_pano_1_1_actions_1_1_load_scene =
[
    [ "LoadType", "class_infinity_code_1_1u_pano_1_1_actions_1_1_load_scene.html#ab37e13bc731f04d4a6dc9a6c132fb9ff", [
      [ "name", "class_infinity_code_1_1u_pano_1_1_actions_1_1_load_scene.html#ab37e13bc731f04d4a6dc9a6c132fb9ffab068931cc450442b63f5b3d276ea4297", null ],
      [ "index", "class_infinity_code_1_1u_pano_1_1_actions_1_1_load_scene.html#ab37e13bc731f04d4a6dc9a6c132fb9ffa6a992d5529f459a44fee58c733255e86", null ]
    ] ],
    [ "loadType", "class_infinity_code_1_1u_pano_1_1_actions_1_1_load_scene.html#a6f4267783c86c986c60079c539ebbf02", null ],
    [ "sceneIndex", "class_infinity_code_1_1u_pano_1_1_actions_1_1_load_scene.html#abe219bd588e62e31a94f09dd9befcd54", null ],
    [ "sceneName", "class_infinity_code_1_1u_pano_1_1_actions_1_1_load_scene.html#a24c4fad4f20cac1f35b299e3c7b3b3a1", null ]
];