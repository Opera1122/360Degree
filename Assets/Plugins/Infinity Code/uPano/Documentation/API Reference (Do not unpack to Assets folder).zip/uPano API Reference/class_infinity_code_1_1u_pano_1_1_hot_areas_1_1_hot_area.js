var class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area =
[
    [ "Contain", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area.html#a0c066c876c6c62b033df5377c2983375", null ],
    [ "GetPanTilt", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area.html#a8f4c507f7597c337bd11d8a3e5b20dfb", null ],
    [ "GetScreenPosition", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area.html#afc593cf5813d14bcc7f69f7109978eae", null ],
    [ "Reinit", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area.html#abe430a81790d2471af6d308778bc1fc1", null ],
    [ "SetPanTilt", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area.html#af71b6e0dca4cd9f648d70b9e926ab301", null ],
    [ "color", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area.html#affdeb37df7102fd6c031b0428d005b67", null ],
    [ "points", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area.html#a8e95bc907ccc7576b14277a2a3b255cc", null ],
    [ "manager", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area.html#afb5ba97c1c238e890814bf90dd9e774b", null ],
    [ "screenPosition", "class_infinity_code_1_1u_pano_1_1_hot_areas_1_1_hot_area.html#a3f23e885d8e1adea453112b401c7f9f6", null ]
];