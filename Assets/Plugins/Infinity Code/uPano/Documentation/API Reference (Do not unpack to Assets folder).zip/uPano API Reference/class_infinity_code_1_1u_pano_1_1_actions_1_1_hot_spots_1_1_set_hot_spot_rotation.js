var class_infinity_code_1_1u_pano_1_1_actions_1_1_hot_spots_1_1_set_hot_spot_rotation =
[
    [ "rotation", "class_infinity_code_1_1u_pano_1_1_actions_1_1_hot_spots_1_1_set_hot_spot_rotation.html#aa83e1db6c1d5f06c610696981afd35e8", null ]
];